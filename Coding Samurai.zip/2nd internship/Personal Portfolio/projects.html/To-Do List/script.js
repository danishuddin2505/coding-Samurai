document.addEventListener("DOMContentLoaded", function () {
    const addTaskBtn = document.getElementById("addTaskBtn");
    const taskForm = document.getElementById("taskForm");
    const saveTaskBtn = document.getElementById("saveTask");
    const clearTaskBtn = document.getElementById("clearTask");
    const clearAllBtn = document.getElementById("clearAll");
    const taskList = document.getElementById("taskList");
    const taskNameInput = document.getElementById("taskName");
    const taskDateTimeInput = document.getElementById("taskDateTime");

    // Show Task Form
    addTaskBtn.addEventListener("click", function () {
        taskForm.style.display = "block";
    });

    // Save Task
    saveTaskBtn.addEventListener("click", function () {
        const taskName = taskNameInput.value.trim();
        const taskDateTime = taskDateTimeInput.value;

        if (taskName === "" || taskDateTime === "") {
            alert("Please enter task name and date/time.");
            return;
        }

        const li = document.createElement("li");

        li.innerHTML = `
            <input type="checkbox" class="complete-checkbox">
            <span class="task-text">${taskName} - ${taskDateTime}</span>
            <button class="btn green edit-task">Edit</button>
            <button class="btn red delete-task">Clear</button>
        `;

        taskList.appendChild(li);

        // Clear inputs
        taskNameInput.value = "";
        taskDateTimeInput.value = "";

        // Mark as Complete
        const checkbox = li.querySelector(".complete-checkbox");
        checkbox.addEventListener("change", function () {
            const taskText = li.querySelector(".task-text");
            if (checkbox.checked) {
                taskText.classList.add("completed");
            } else {
                taskText.classList.remove("completed");
            }
        });

        // Delete Task
        li.querySelector(".delete-task").addEventListener("click", function () {
            li.remove();
        });

        // Edit Task
        li.querySelector(".edit-task").addEventListener("click", function () {
            const currentText = li.querySelector(".task-text").textContent;
            const [namePart, datePart] = currentText.split(" - ");

            // Fill form for editing
            taskNameInput.value = namePart.trim();
            taskDateTimeInput.value = datePart.trim();
            taskForm.style.display = "block";

            // Remove old task
            li.remove();
        });
    });

    // Clear Form Inputs
    clearTaskBtn.addEventListener("click", function () {
        taskNameInput.value = "";
        taskDateTimeInput.value = "";
    });

    // Clear All Tasks
    clearAllBtn.addEventListener("click", function () {
        taskList.innerHTML = "";
    });
});

console.log("YOU CAN DO IT");
