// Resume button confirmation
document.addEventListener("DOMContentLoaded", function() {
    let resumeBtn = document.querySelector(".btn[href='resume.pdf']");
    if (resumeBtn) {
        resumeBtn.addEventListener("click", function(event) {
            let confirmOpen = confirm("Do you want to open the resume?");
            if (!confirmOpen) {
                event.preventDefault(); // Resume open hone se rokne ke liye
            }
        });
    }
});

// Work/Project button animation
document.addEventListener("DOMContentLoaded", function() {
    let workBtn = document.querySelector(".btn[href='projects.html']");
    if (workBtn) {
        workBtn.addEventListener("mouseover", function() {
            workBtn.style.transform = "scale(1.1)";
            workBtn.style.transition = "0.3s";
        });

        workBtn.addEventListener("mouseout", function() {
            workBtn.style.transform = "scale(1)";
        });
    }
});

// Contact form validation
document.addEventListener("DOMContentLoaded", function() {
    let contactForm = document.querySelector("#contact-form");
    if (contactForm) {
        contactForm.addEventListener("submit", function(event) {
            let email = document.querySelector("#email").value;
            let message = document.querySelector("#message").value;

            if (email.trim() === "" || message.trim() === "") {
                alert("Please fill in all fields!");
                event.preventDefault(); // Form submit hone se rokne ke liye
            }
        });
    }
});
